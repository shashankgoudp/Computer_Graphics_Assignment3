How to Execute ?

Double click on the index.html and once it is opened in the browser,append the url with ?hierarchy=hierarchy.txt

I placed all the obj,mtl and hierarchy file in the obj folder.
I placed all the texture images in textures folder.

I have used head,rabbit and capsule models. I used the theme called " when a man takes a capsule, he will be turned into Rabbit".

I have calculated frames per second and it will be displayed at the top left corner.

I have made the bounding box in cube and whenever space bar is pressed, bounding box is shifted to the next node in the hierarchy.

Citations:

Below are the sources from which I used the code for this assignment

Lesson4 and lesson 6 in : https://github.com/gpjt/webgl-lessons

For handling Transformation logic: http://stackoverflow.com/questions/5597060/detecting-arrow-key-presses-in-javascript

for reading and parsing a file : http://stackoverflow.com/questions/14446447/javascript-read-local-text-file

for calculating frames per second: http://stackoverflow.com/questions/16432804/recording-fps-in-webgl

